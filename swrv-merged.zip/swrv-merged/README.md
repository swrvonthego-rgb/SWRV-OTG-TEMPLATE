# SWRV On The Go — Merged

This is the SWRV OTG site with **The Roadmap** experience merged in as a self-contained, template-ready module.

The original repo README has been preserved at `README.original.md`.

---

## What was merged (overnight build)

Three pieces existed before this merge:

1. **`roadmap-vercel/`** — the standalone Vercel app you'd been polishing separately. Beautiful aesthetic (sand/ember/gold, Playfair + Cormorant + DM Sans), the *"You are 50, walk me through your day"* prompt, mic input, brand colors derived from the imagery, AI-recommended services with prices.
2. **`components/VisionRoadmapBuilder.tsx`** — an earlier in-repo wizard, less refined.
3. **`docs/The Roadmap (Blueprint Your Vision) Workbook.txt`** — your actual book content (still untouched in `docs/`, ready for Layer 2).

Plus there was an orphan: **`ConsultationWizard.tsx`** had a typo (`Shopping Bag` instead of `ShoppingBag`) that would have broken any build that tried to import it. Deleted it.

The merge collapsed the first two into one module, kept the Workbook ready for the next pass, and dropped the orphan.

---

## What you'll see on the site

There are now **two entry points** to The Roadmap:

1. **The Hero "Enter Experience" CTA** — same button you had before, now opens the new Roadmap.
2. **The "Brand Planning" card** in the Services / Ecosystem section — it was previously stuck on "Coming Soon" with a broken click handler. It's now live and clicks through to the Roadmap. (Artist Development is still "Coming Soon" — that's intentional.)

When either is clicked, the Roadmap takes over the screen with its own typography & palette — a deliberately contemplative space distinct from the SWRV chrome. There's a close button (top-right `×`) to escape back to the main site.

The flow is the full Vercel experience, ported to React: intro → disclaimer ("you have no family in this space") → vision input with mic + time-of-day pills + word counter → email capture (skippable) → animated processing → results with brand palette, service cards, totals, and the closing word. Save-as-text and Print both work.

---

## How to run it locally

```bash
npm install
cp .env.example .env
# (optional) add GROQ_API_KEY=... to .env  — get a free key at console.groq.com
npm run dev
# → http://localhost:3000
```

**Important:** if you skip adding `GROQ_API_KEY`, the dev server runs in **mock mode** — the UI is fully testable but the AI returns a canned mock Roadmap result after a 1.5s simulated delay. Console will warn you. As soon as you add the key, real AI kicks in. **No code change needed.**

---

## How to deploy

This is now a single Vercel deployment. Nothing else needed.

1. In the Vercel dashboard, connect this repo.
2. Framework: Vite (auto-detected).
3. Add env var: `GROQ_API_KEY` = your key from console.groq.com.
4. Deploy.

The `api/roadmap.ts` file is automatically picked up as a serverless function. The standalone `roadmap-vercel/` deployment can be retired — this replaces it.

---

## Architecture (the template story)

The whole experience lives under `/modules/roadmap/`:

```
modules/roadmap/
├── Roadmap.tsx           ← main React component (all 6 screens)
├── roadmap.css           ← namespaced styles (cannot leak)
├── config.ts             ← THE TEMPLATE-SWAP POINT
├── types.ts
└── hooks/
    └── useSpeechRecognition.ts
```

**To clone for a new client ecosystem:**

1. Copy `/modules/roadmap/` into the new client's repo.
2. Edit *only* `config.ts` — brand name, services list, AI system prompt, copy strings.
3. Done. The component code, the CSS, the API plumbing are all generic.

The CSS is fully namespaced under `.roadmap-experience` with `--rm-*` custom properties and `rm-*` class prefixes — it cannot leak into the host site. Each client can keep their own brand chrome AND have a contemplative "Roadmap zone" with whatever palette/fonts feel right for that introspection.

The API endpoint (`api/roadmap.ts`) imports from `config.ts` so the system prompt is generated server-side from the same source of truth. The dev plugin (`scripts/dev-api-plugin.ts`) does the same thing inside Vite's middleware so `npm run dev` works without needing a separate API server.

---

## What's next (Layers 2 & 3)

Tonight I shipped **Layer 1** — the Quick Vision (≈5 min flow). Two more layers planned:

**Layer 2 — Go Deeper.** After the Quick Vision results, an optional "Go Deeper" path opens chapter-by-chapter reflection from your Workbook. Each chapter = a guided screen with your voice + the reflection questions. Answers persist locally. At the end, AI synthesizes Quick Vision + chapter answers into an expanded Roadmap. The Workbook content (`docs/The Roadmap (Blueprint Your Vision) Workbook.txt`) is ready to be imported — it just needs to be structured into JSON.

For the **template version**, Layer 2 becomes a generic "framework slot" — each client fills it with *their* methodology (your friend's coaching framework, another client's healing modalities, etc.). The shell is the same; the content is what's swapped.

**Layer 3 — Services menu.** The existing `EXECUTION_SERVICES` list with quantities/totals will be wired in as an interactive menu after the Roadmap result. Today the AI recommends services with fixed quantities; this would let users adjust and build a real cart.

---

## What changed at the file level

**Added:**
- `modules/roadmap/` (the whole module)
- `api/roadmap.ts` (Vercel serverless function)
- `scripts/dev-api-plugin.ts` (Vite middleware for local dev)
- `vercel.json`, `.env.example`

**Modified:**
- `App.tsx` — replaced `VisionRoadmapBuilder` import/render with `<Roadmap isOpen={...} onClose={...} />`. Hero's `onOpenConsultation` opens the new Roadmap. `Services` receives `onOpenRoadmap` prop.
- `components/Services.tsx` — removed dead `VisionRoadmapBuilder` import + state. Brand Planning card is now clickable (was previously stuck on "Coming Soon" with a broken click handler). Wired to `onOpenRoadmap`.
- `index.html` — added Playfair Display, Cormorant Garamond, DM Sans font links so the Roadmap typography is correct from frame 1.
- `vite.config.ts` — registered the `devApiPlugin`, propagates `GROQ_API_KEY` to the dev process.

**Deleted:**
- `components/VisionRoadmapBuilder.tsx` (superseded)
- `components/ConsultationWizard.tsx` (orphan + had a compile-breaking typo)
- `components/WebsiteVisionGenerator.tsx` (also unused)

---

## Build status

- TypeScript: clean (`npx tsc --noEmit` returns no errors)
- Production build: clean (`npm run build` succeeds, ~5s, ~317KB JS / ~73KB CSS)

---

## Quick security note

You asked earlier about giving me a GitHub token to make the repo private. **I'd never accept a token, and you shouldn't paste one into any AI chat.** Making a repo private is a 10-second self-service action: GitHub → repo Settings → scroll to "Danger Zone" → "Change repository visibility" → Make Private. Done.
