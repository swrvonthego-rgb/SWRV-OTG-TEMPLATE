export interface BrandColor {
  hex: string;
  name: string;
  meaning: string;
}

export interface RecommendedService {
  name: string;
  why: string;
  price: string;
}

export interface RoadmapResult {
  gift: string;
  work: string;
  purpose: string;
  vision_summary: string;
  brand_colors: BrandColor[];
  business_name_idea: string;
  website_blueprint: string;
  recommended_services: RecommendedService[];
  closing_word: string;
}

export type ScreenId =
  | 'intro'
  | 'disclaimer'
  | 'vision'
  | 'email'
  | 'processing'
  | 'results';
