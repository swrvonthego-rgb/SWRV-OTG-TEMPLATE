import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import './roadmap.css';
import { RoadmapConfig, SWRV_ROADMAP_CONFIG } from './config';
import { RoadmapResult, ScreenId } from './types';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';

// ════════════════════════════════════════════════════════════
// PROPS
// ════════════════════════════════════════════════════════════
export interface RoadmapProps {
  /** Show or hide the experience (renders fullscreen overlay when open) */
  isOpen: boolean;
  /** Called when the user closes the experience */
  onClose: () => void;
  /** Per-client configuration. Defaults to SWRV. */
  config?: RoadmapConfig;
  /** API endpoint for the AI. Defaults to /api/roadmap. */
  apiEndpoint?: string;
}

// ════════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════════

const PROGRESS_PCT: Record<ScreenId, number> = {
  intro: 0,
  disclaimer: 20,
  vision: 40,
  email: 55,
  processing: 70,
  results: 100,
};

/** Detect a time-of-day pill from the textarea content. */
function detectLitPills(text: string): Set<string> {
  const t = text.toLowerCase();
  const map: Record<string, string[]> = {
    morning: ['morning', 'waking', 'wake', 'sunrise', 'breakfast', 'coffee', 'dawn'],
    afternoon: ['afternoon', 'lunch', 'midday', 'noon'],
    evening: ['evening', 'sunset', 'dinner', 'dusk'],
    night: ['night', 'sleep', 'bed', 'stars', 'moonlight', 'late'],
  };
  const lit = new Set<string>();
  for (const [key, kws] of Object.entries(map)) {
    if (kws.some((k) => t.includes(k))) lit.add(key);
  }
  return lit;
}

function wordCount(s: string): number {
  return s.trim().split(/\s+/).filter((w) => w.length > 0).length;
}

/** Tiny markdown-ish parser for the disclaimer body — converts **bold** spans. */
function renderInlineEmphasis(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((p, i) => {
    if (p.startsWith('**') && p.endsWith('**')) {
      return <strong key={i}>{p.slice(2, -2)}</strong>;
    }
    return <React.Fragment key={i}>{p}</React.Fragment>;
  });
}

// ════════════════════════════════════════════════════════════
// COMPONENT
// ════════════════════════════════════════════════════════════
export const Roadmap: React.FC<RoadmapProps> = ({
  isOpen,
  onClose,
  config = SWRV_ROADMAP_CONFIG,
  apiEndpoint = '/api/roadmap',
}) => {
  const [screen, setScreen] = useState<ScreenId>('intro');
  const [progress, setProgress] = useState(0);

  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [nameError, setNameError] = useState(false);

  const [vision, setVision] = useState('');
  const [interimVision, setInterimVision] = useState(''); // live speech
  const [shake, setShake] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const [activeStep, setActiveStep] = useState(0); // for processing animation
  const [doneSteps, setDoneSteps] = useState<Set<number>>(new Set());
  const [showTimeout, setShowTimeout] = useState(false);

  const [result, setResult] = useState<RoadmapResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);

  // ─── Speech recognition ───────────────────────────────────
  const handleTranscript = useCallback((appendFinal: string, interim: string) => {
    if (appendFinal) {
      setVision((prev) => {
        const sep = prev && !prev.endsWith(' ') ? ' ' : '';
        return prev + sep + appendFinal;
      });
      setInterimVision('');
    } else {
      setInterimVision(interim);
    }
  }, []);

  const mic = useSpeechRecognition({ onTranscript: handleTranscript });

  // ─── Effective vision (committed text + live interim) ────
  const effectiveVision = useMemo(() => {
    if (!interimVision) return vision;
    const sep = vision && !vision.endsWith(' ') ? ' ' : '';
    return vision + sep + interimVision;
  }, [vision, interimVision]);

  const litPills = useMemo(() => detectLitPills(effectiveVision), [effectiveVision]);
  const words = useMemo(() => wordCount(effectiveVision), [effectiveVision]);

  // ─── Progress bar updater ─────────────────────────────────
  useEffect(() => {
    setProgress(PROGRESS_PCT[screen]);
  }, [screen]);

  // ─── Reset state when closed ──────────────────────────────
  useEffect(() => {
    if (!isOpen) {
      mic.stop();
    } else {
      // When opening, scroll the inner scroll container to the top
      window.scrollTo(0, 0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  // ─── Toast helper ─────────────────────────────────────────
  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => setToast(null), 3200);
  }, []);

  // ─── Navigation ───────────────────────────────────────────
  const goTo = useCallback((id: ScreenId) => {
    setScreen(id);
    // Reset scroll inside the experience container
    window.requestAnimationFrame(() => {
      const exp = document.querySelector('.roadmap-experience');
      if (exp) exp.scrollTop = 0;
    });
  }, []);

  const handleStartOver = useCallback(() => {
    mic.stop();
    setVision('');
    setInterimVision('');
    setUserName('');
    setUserEmail('');
    setNameError(false);
    setResult(null);
    setError(null);
    setActiveStep(0);
    setDoneSteps(new Set());
    setShowTimeout(false);
    goTo('intro');
  }, [goTo, mic]);

  // ─── Intro → Disclaimer ───────────────────────────────────
  const goToDisclaimer = useCallback(() => {
    if (!userName.trim()) {
      setNameError(true);
      window.setTimeout(() => setNameError(false), 2000);
      nameInputRef.current?.focus();
      return;
    }
    goTo('disclaimer');
  }, [userName, goTo]);

  // ─── Vision → Email ───────────────────────────────────────
  const submitVision = useCallback(() => {
    mic.stop();
    if (words < 30) {
      setShake(true);
      window.setTimeout(() => setShake(false), 500);
      showToast('Paint the full picture — morning, work, evening, night.');
      return;
    }
    goTo('email');
  }, [words, mic, showToast, goTo]);

  // ─── Email → Processing → AI Call ─────────────────────────
  const callApi = useCallback(
    async (visionText: string) => {
      const timeoutPromise = new Promise<never>((_, reject) =>
        window.setTimeout(() => reject(new Error('TIMEOUT')), 45000),
      );

      try {
        const fetchPromise = fetch(apiEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: [
              {
                role: 'user',
                content: `Name: ${userName}\nEmail: ${userEmail || 'not provided'}\n\nVision:\n${visionText}`,
              },
            ],
          }),
        });

        const res = (await Promise.race([fetchPromise, timeoutPromise])) as Response;

        if (!res.ok) {
          const errData = await res.json().catch(() => ({} as any));
          throw new Error(errData.error || `HTTP ${res.status}`);
        }

        const data = await res.json();
        const raw = (data.content || [])
          .map((b: { text?: string }) => b.text || '')
          .join('');
        const clean = raw.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
        const parsed: RoadmapResult = JSON.parse(clean);

        // mark final step done
        setActiveStep(-1);
        setDoneSteps(new Set([0, 1, 2, 3, 4]));
        setResult(parsed);
        setError(null);
        goTo('results');
      } catch (err: any) {
        if (err.message === 'TIMEOUT') {
          setError('The response is taking too long. Your vision is saved — tap Try Again.');
        } else if (err.message?.includes('Failed to fetch') || err.message?.includes('NetworkError')) {
          setError('Connection issue. Check your internet and try again.');
        } else {
          setError(err.message || 'Something went sideways. Your vision is safe — tap Try Again.');
        }
        goTo('results');
      }
    },
    [apiEndpoint, userName, userEmail, goTo],
  );

  const proceedToProcess = useCallback(
    (skipEmail = false) => {
      if (skipEmail) setUserEmail('');
      goTo('processing');
      setActiveStep(0);
      setDoneSteps(new Set());
      setShowTimeout(false);

      // Animate steps then fire the API call
      const totalSteps = config.copy.processingSteps.length;
      const stepInterval = 950;
      let i = 0;

      const tick = () => {
        if (i > 0) {
          setDoneSteps((prev) => new Set(prev).add(i - 1));
        }
        if (i < totalSteps) {
          setActiveStep(i);
          i += 1;
          if (i < totalSteps) {
            window.setTimeout(tick, stepInterval);
          } else {
            // Final step stays "active" while API runs
            callApi(vision);
          }
        }
      };
      window.setTimeout(tick, 200);

      // Show the "taking longer" message after 20s
      window.setTimeout(() => setShowTimeout(true), 20000);
    },
    [config.copy.processingSteps.length, callApi, vision, goTo],
  );

  // ─── Save as text file ────────────────────────────────────
  const handleSave = useCallback(() => {
    if (!result) return;
    const date = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const total = (result.recommended_services || []).reduce((sum, s) => {
      const n = parseInt((s.price || '').replace(/\D/g, ''));
      return sum + (isNaN(n) ? 0 : n);
    }, 0);

    const lines: string[] = [];
    lines.push(`THE ROADMAP — ${userName}`);
    lines.push(`Generated by ${config.brandName} · ${config.brandUrl}`);
    lines.push(`Mapped on ${date}`);
    lines.push('─'.repeat(44));
    lines.push('');
    lines.push('YOUR GIFT');
    lines.push(result.gift);
    lines.push('');
    lines.push('YOUR WORK');
    lines.push(result.work);
    lines.push('');
    lines.push('YOUR PURPOSE');
    lines.push(result.purpose);
    lines.push('');
    lines.push('YOUR HAPPILY EVER AFTER — MAPPED');
    lines.push(result.vision_summary);
    lines.push('');
    lines.push('YOUR BRAND IDENTITY');
    lines.push(result.business_name_idea);
    lines.push(result.website_blueprint);
    lines.push('');
    lines.push('BRAND COLORS');
    (result.brand_colors || []).forEach((c) => {
      lines.push(`  ${c.name} (${c.hex}) — ${c.meaning}`);
    });
    lines.push('');
    lines.push('RECOMMENDED SERVICES');
    (result.recommended_services || []).forEach((s) => {
      lines.push(`  ${s.name} — ${s.price}`);
      lines.push(`    ${s.why}`);
    });
    lines.push('');
    lines.push(`TOTAL ESTIMATED INVESTMENT: $${total.toLocaleString()}`);
    lines.push('');
    lines.push('A WORD FOR YOU');
    lines.push(result.closing_word);

    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${userName.replace(/\s+/g, '_')}_Roadmap_${config.brandName.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
    showToast('Roadmap saved ✓');
  }, [result, userName, config, showToast]);

  // ─── Update textarea with combined committed + interim ───
  // (Show the live interim as we speak, but only commit final text to state.)
  useEffect(() => {
    if (textareaRef.current && document.activeElement !== textareaRef.current) {
      textareaRef.current.value = effectiveVision;
    }
  }, [effectiveVision]);

  // ─── Don't render anything when closed ────────────────────
  if (!isOpen) return null;

  // ════════════════════════════════════════════════════════════
  // RENDER
  // ════════════════════════════════════════════════════════════
  const total = result
    ? (result.recommended_services || []).reduce((sum, s) => {
        const n = parseInt((s.price || '').replace(/\D/g, ''));
        return sum + (isNaN(n) ? 0 : n);
      }, 0)
    : 0;

  // Pick a "headline" sentence from the closing word for the CTA card
  const closingForCta = (result?.closing_word || '').trim();
  const firstEnd = closingForCta.search(/(?<=[.!?])\s+[A-Z]/);
  const ctaHeadline =
    firstEnd > 0
      ? closingForCta.substring(0, firstEnd + 1)
      : closingForCta.split(/[.!?]/)[0] + (closingForCta ? '.' : '');

  const date = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="roadmap-experience" role="dialog" aria-modal="true" aria-label="The Roadmap Experience">
      <div className="rm-progress" style={{ width: `${progress}%` }} />

      {/* Close button — host site escape hatch */}
      <button
        type="button"
        className="rm-close"
        onClick={onClose}
        aria-label="Close The Roadmap"
        title="Close"
      >
        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
          <path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z" />
        </svg>
      </button>

      {/* ════════ SCREEN 1 — INTRO ════════ */}
      <section
        id="rm-screen-intro"
        className={`rm-screen ${screen === 'intro' ? 'active' : ''}`}
      >
        <div className="rm-grain" />
        <div className="rm-intro-content">
          <span className="rm-logo-mark">{config.copy.introLogo}</span>
          <h1 className="rm-intro-title">
            {config.copy.introTitle.line1}
            <br />
            <em>{config.copy.introTitle.emphasis}</em>
            <br />
            {config.copy.introTitle.line3}
          </h1>
          <p className="rm-intro-sub">{config.copy.introSub}</p>

          <div className="rm-video-wrap">
            <button
              type="button"
              className="rm-video-cover"
              onClick={() => showToast('Video dropping soon — Swerve is recording 🎬')}
            >
              <span className="rm-play-ring">
                <svg viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </span>
              <span className="rm-video-label">{config.copy.videoLabel}</span>
            </button>
          </div>

          <div className="rm-name-field-wrap">
            <label className="rm-field-label" htmlFor="rm-user-name">
              {config.copy.nameFieldLabel}
            </label>
            <input
              ref={nameInputRef}
              id="rm-user-name"
              className={`rm-text-input ${nameError ? 'error' : ''}`}
              type="text"
              placeholder={nameError ? 'Please enter your name' : config.copy.namePlaceholder}
              maxLength={40}
              autoComplete="given-name"
              autoCorrect="off"
              spellCheck={false}
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') goToDisclaimer();
              }}
            />
          </div>

          <button type="button" className="rm-btn-primary" onClick={goToDisclaimer}>
            {config.copy.introCta}
          </button>
        </div>
      </section>

      {/* ════════ SCREEN 2 — DISCLAIMER ════════ */}
      <section
        id="rm-screen-disclaimer"
        className={`rm-screen ${screen === 'disclaimer' ? 'active' : ''}`}
      >
        <div className="rm-disc-box">
          <div className="rm-disc-ornament">
            <span />
            <svg viewBox="0 0 24 24">
              <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
            </svg>
            <span />
          </div>
          <h2 className="rm-disc-title">
            {config.copy.disclaimerTitle.line1}
            <br />
            {config.copy.disclaimerTitle.line2}
          </h2>
          {config.copy.disclaimerBody.map((p, i) => (
            <p key={i} className="rm-disc-text">
              {renderInlineEmphasis(p)}
            </p>
          ))}
          <hr className="rm-disc-rule" />
          <p className="rm-disc-note">{config.copy.disclaimerNote}</p>
          <div className="rm-btn-row">
            <button type="button" className="rm-btn-ghost" onClick={() => goTo('intro')}>
              {config.copy.disclaimerBack}
            </button>
            <button type="button" className="rm-btn-primary" onClick={() => goTo('vision')}>
              {config.copy.disclaimerNext}
            </button>
          </div>
        </div>
      </section>

      {/* ════════ SCREEN 3 — VISION INPUT ════════ */}
      <section
        id="rm-screen-vision"
        className={`rm-screen ${screen === 'vision' ? 'active' : ''}`}
      >
        <nav className="rm-vision-nav">
          <span className="rm-logo-mark" style={{ margin: 0 }}>
            The Roadmap
          </span>
          <span className="rm-step-label">Your Vision</span>
        </nav>
        <div className="rm-vision-main">
          <h2 className="rm-vision-prompt">
            {config.copy.visionPrompt.line1} <em>{config.copy.visionPrompt.emphasis}</em>
            <br />
            {config.copy.visionPrompt.line3.split('\n').map((line, i, arr) => (
              <React.Fragment key={i}>
                {line}
                {i < arr.length - 1 ? <br /> : null}
              </React.Fragment>
            ))}
          </h2>
          <p className="rm-vision-sub">{config.copy.visionSub}</p>

          <div className="rm-time-row">
            {(['morning', 'afternoon', 'evening', 'night'] as const).map((key) => {
              const labels = {
                morning: '☀ Morning',
                afternoon: '◑ Afternoon',
                evening: '◐ Evening',
                night: '☽ Night',
              };
              return (
                <div key={key} className={`rm-time-pill ${litPills.has(key) ? 'lit' : ''}`}>
                  {labels[key]}
                </div>
              );
            })}
          </div>

          <textarea
            ref={textareaRef}
            className={`rm-vision-textarea ${shake ? 'shake' : ''}`}
            placeholder={config.copy.visionPlaceholder}
            value={effectiveVision}
            onChange={(e) => {
              setVision(e.target.value);
              setInterimVision('');
            }}
            onFocus={(e) => {
              window.setTimeout(() => {
                e.target.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }, 300);
            }}
          />

          <div className="rm-mic-section">
            <button
              type="button"
              className={`rm-mic-btn ${mic.isListening ? 'recording' : ''}`}
              onClick={mic.toggle}
              title="Speak your vision"
              aria-label="Toggle voice input"
              disabled={mic.state === 'unsupported'}
            >
              <svg viewBox="0 0 24 24">
                <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm-1-9c0-.55.45-1 1-1s1 .45 1 1v6c0 .55-.45 1-1 1s-1-.45-1-1V5zm6 6c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
              </svg>
            </button>
            <div className={`rm-viz-bars ${mic.isListening ? 'active' : ''}`}>
              {mic.bars.map((h, i) => (
                <div key={i} className="rm-viz-bar" style={{ height: `${h}px` }} />
              ))}
            </div>
            <span className="rm-mic-status">
              {mic.state === 'unsupported' && 'Not supported — use Chrome or Edge'}
              {mic.state === 'blocked' && 'Mic blocked — allow mic in browser settings'}
              {mic.state === 'network-error' && 'Network error — check connection'}
              {mic.state === 'requesting' && 'Asking for mic permission…'}
              {mic.state === 'listening' && 'Listening — tap to stop'}
              {mic.state === 'idle' && 'Tap to speak'}
            </span>
            {mic.state === 'idle' && <span className="rm-mic-note">Chrome / Edge recommended</span>}
          </div>

          <div className="rm-word-counter">
            {words} word{words !== 1 ? 's' : ''}
          </div>

          <div className="rm-vision-footer">
            <span className="rm-char-hint">
              {words > 0 && words < 30 ? `${30 - words} more words to unlock` : ''}
            </span>
            <button type="button" className="rm-btn-primary" onClick={submitVision}>
              {config.copy.visionCta}
            </button>
          </div>
        </div>
      </section>

      {/* ════════ SCREEN 3.5 — EMAIL ════════ */}
      <section
        id="rm-screen-email"
        className={`rm-screen ${screen === 'email' ? 'active' : ''}`}
      >
        <div className="rm-email-box">
          <div className="rm-disc-ornament" style={{ marginBottom: 28 }}>
            <span />
            <svg viewBox="0 0 24 24">
              <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" />
            </svg>
            <span />
          </div>
          <h2 className="rm-email-title">
            {config.copy.emailTitle.line1}
            <br />
            {config.copy.emailTitle.line2}
          </h2>
          <p className="rm-email-sub">{config.copy.emailSub}</p>
          <div className="rm-email-fields">
            <input
              className="rm-text-input"
              type="email"
              placeholder="your@email.com"
              autoComplete="email"
              value={userEmail}
              onChange={(e) => setUserEmail(e.target.value)}
              style={{ maxWidth: '100%', textAlign: 'left', padding: '14px 18px', fontSize: 16 }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') proceedToProcess(false);
              }}
            />
          </div>
          <button
            type="button"
            className="rm-btn-primary"
            onClick={() => proceedToProcess(false)}
            style={{ width: '100%', maxWidth: 360 }}
          >
            {config.copy.emailCta}
          </button>
          <button type="button" className="rm-skip-link" onClick={() => proceedToProcess(true)}>
            {config.copy.emailSkip}
          </button>
        </div>
      </section>

      {/* ════════ SCREEN 4 — PROCESSING ════════ */}
      <section
        id="rm-screen-processing"
        className={`rm-screen ${screen === 'processing' ? 'active' : ''}`}
      >
        <div className="rm-processing-wrap">
          <div className="rm-orb">
            <div className="rm-orb-ring" />
            <div className="rm-orb-ring" />
            <div className="rm-orb-ring" />
            <div className="rm-orb-core" />
          </div>
          <h2 className="rm-proc-title">{config.copy.processingTitle}</h2>
          <p className="rm-proc-name">{userName ? `${userName}, this is your truth.` : ''}</p>
          <ul className="rm-proc-steps">
            {config.copy.processingSteps.map((label, i) => {
              const klass = doneSteps.has(i) ? 'done' : activeStep === i ? 'active' : '';
              return (
                <li key={i} className={`rm-proc-step ${klass}`}>
                  <div className="rm-step-dot" />
                  {label}
                </li>
              );
            })}
          </ul>
          <p className={`rm-timeout-msg ${showTimeout ? 'visible' : ''}`}>
            Taking a little longer than usual — still working on your vision...
            <br />
            <span style={{ fontSize: 11, opacity: 0.6 }}>Do not refresh the page.</span>
          </p>
        </div>
      </section>

      {/* ════════ SCREEN 5 — RESULTS ════════ */}
      <section
        id="rm-screen-results"
        className={`rm-screen ${screen === 'results' ? 'active' : ''}`}
      >
        {error ? (
          <div className="rm-results-content">
            <div className="rm-r-card" style={{ textAlign: 'center', padding: '56px 28px' }}>
              <div className="rm-r-label" style={{ justifyContent: 'center' }}>
                We hit a snag
              </div>
              <div className="rm-r-body" style={{ marginTop: 14, opacity: 0.6, fontSize: 16 }}>
                {error}
              </div>
              <button
                type="button"
                className="rm-btn-primary"
                style={{ marginTop: 32 }}
                onClick={() => {
                  setError(null);
                  goTo('vision');
                }}
              >
                ← Try Again
              </button>
            </div>
          </div>
        ) : result ? (
          <>
            <div className="rm-results-hero">
              <span className="rm-logo-mark">{config.copy.introLogo}</span>
              <h1 className="rm-results-headline">
                {config.copy.resultsHeadline.plain} <em>{config.copy.resultsHeadline.emphasis}</em>
              </h1>
              <p className="rm-results-meta">
                {userName} · Mapped on {date}
              </p>
              <div className="rm-action-row">
                <button type="button" className="rm-btn-save" onClick={handleSave}>
                  <svg viewBox="0 0 24 24">
                    <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" />
                  </svg>
                  Save Roadmap
                </button>
                <button type="button" className="rm-btn-save" onClick={() => window.print()}>
                  <svg viewBox="0 0 24 24">
                    <path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z" />
                  </svg>
                  Print
                </button>
              </div>
            </div>

            <div className="rm-results-content">
              <div className="rm-r-card">
                <div className="rm-r-label">Your Gift</div>
                <div className="rm-r-title">{result.gift}</div>
              </div>
              <div className="rm-r-card">
                <div className="rm-r-label">Your Work</div>
                <div className="rm-r-body">{result.work}</div>
              </div>
              <div className="rm-r-card">
                <div className="rm-r-label">Your Purpose</div>
                <div className="rm-r-body">{result.purpose}</div>
              </div>
              <div className="rm-r-card">
                <div className="rm-r-label">Your Happily Ever After — Mapped</div>
                <div className="rm-r-body">{result.vision_summary}</div>
              </div>
              <div className="rm-r-card">
                <div className="rm-r-label">Your Brand Identity</div>
                <div className="rm-r-title">{result.business_name_idea}</div>
                <div className="rm-r-body" style={{ marginBottom: 22 }}>
                  {result.website_blueprint}
                </div>
                <div className="rm-brand-pal">
                  {(result.brand_colors || []).map((c, i) => (
                    <div key={i} className="rm-pal-item">
                      <div className="rm-pal-circle" style={{ background: c.hex }} />
                      <div className="rm-pal-name">
                        {c.name}
                        <br />
                        <small style={{ opacity: 0.4, fontSize: 9 }}>{c.hex}</small>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="rm-color-meanings">
                  {(result.brand_colors || []).map((c, i) => (
                    <div key={i} className="rm-color-meaning-row">
                      <div className="rm-color-dot" style={{ background: c.hex }} />
                      <span>
                        <strong style={{ color: 'var(--rm-linen)', opacity: 0.85 }}>
                          {c.name}:
                        </strong>{' '}
                        {c.meaning}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rm-r-card">
                <div className="rm-r-label">What It Takes — {config.brandName} Services</div>
                <div className="rm-services-grid">
                  {(result.recommended_services || []).map((s, i) => (
                    <div key={i} className="rm-svc-card">
                      <div className="rm-svc-name">{s.name}</div>
                      <div className="rm-svc-why">{s.why}</div>
                      <div className="rm-svc-price">{s.price}</div>
                    </div>
                  ))}
                </div>
                <div className="rm-total-row">
                  <span className="rm-total-label">Estimated Investment</span>
                  <span className="rm-total-amount">${total.toLocaleString()}</span>
                </div>
              </div>
              <div className="rm-cta-block">
                <div className="rm-cta-eyebrow">What's Next</div>
                <div className="rm-cta-headline">{ctaHeadline}</div>
                <p className="rm-cta-body">{result.closing_word}</p>
                <a
                  href={config.ctaUrl}
                  className="rm-btn-cta"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {config.copy.resultsCtaButton}
                </a>
                <button type="button" className="rm-reset-btn" onClick={handleStartOver}>
                  ← Start a New Vision
                </button>
              </div>
            </div>
          </>
        ) : null}
      </section>

      {toast && <div className="rm-toast show">{toast}</div>}
    </div>
  );
};

export default Roadmap;
